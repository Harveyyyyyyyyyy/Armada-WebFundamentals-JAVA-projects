public class modulusOperatorMHCO {
    public static void main(String[] args) {
        int a = 5, b = 2;
        int result = (a % b);
        if (result == 0) {
            System.out.println("No remainder");
        }
        else { 
            System.out.println("Remainder is: " + result);
        }
    }
}
