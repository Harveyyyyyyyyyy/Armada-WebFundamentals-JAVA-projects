public class relationalOperatorsMHCO {
    public static void main(String[] args) {
        int x = 9, y = 2;

        System.out.println(x == y);
        System.out.println(x != y);
        System.out.println(x > y);
        System.out.println(x < y);
        System.out.println(x >= y);
        System.out.println(x <= y);

        if (x < 10) {
            System.out.println(x + " is less than to 10");
        }
    }
}
