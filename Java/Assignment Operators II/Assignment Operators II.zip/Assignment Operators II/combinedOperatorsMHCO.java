// Task 3
public class combinedOperatorsMHCO {
    public static void main(String[] args) {
        int a = 10;
        int b = 10;

        if (a >= 0 && b >=0) {
           a = (a + b);
           b = (a * 2);

           System.out.println("Value of a is: " + a);
           System.out.println("Value of b is: " + b);
        }
    }
}
