// Task 2
public class assignmentOperatorsMHCO {
    public static void main(String[] args) {
        int x = 10;
        x -= 3;
        
        System.out.println(x);

        double initial_price = 100;
        initial_price *= (1 - .20);
        initial_price *= (1 + .10);

        System.out.println(initial_price);
    }
}
