// Task 1
public class logicalOperatorsMHCO {
    public static void main(String[] args) {
        int credit_score = 701;
        int annual_income = 50001;

        if (credit_score > 700 && annual_income > 50000) {
            System.out.println("Eligible for a loan");
        }           
        else {
            System.out.println("Not eligible for a loan");
        }

    }
}